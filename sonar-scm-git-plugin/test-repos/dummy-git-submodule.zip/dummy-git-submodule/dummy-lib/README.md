# dummy-lib

project to use in tests where submodules are needed